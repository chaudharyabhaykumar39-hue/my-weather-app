package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class WeatherUiState {
    object Loading : WeatherUiState()
    data class Success(
        val city: CityEntity,
        val current: CurrentWeatherResponse,
        val forecast: ForecastResponse,
        val airQuality: AirQualityResponse
    ) : WeatherUiState()
    data class Error(val message: String) : WeatherUiState()
}

class WeatherViewModel(private val repository: WeatherRepository) : ViewModel() {

    private val _uiState = MutableStateFlow<WeatherUiState>(WeatherUiState.Loading)
    val uiState: StateFlow<WeatherUiState> = _uiState.asStateFlow()

    private val _searchResults = MutableStateFlow<List<GeocodingResponse>>(emptyList())
    val searchResults = _searchResults.asStateFlow()

    val savedCities = repository.savedCities.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        viewModelScope.launch {
            savedCities.collect { cities ->
                if (cities.isEmpty()) {
                    // Default to Kathmandu if no cities saved
                    val defaultCity = CityEntity("Kathmandu", 27.7083, 85.3206, "NP", true)
                    repository.saveCity(defaultCity)
                    loadWeatherData(defaultCity)
                } else {
                    loadWeatherData(cities.first())
                }
            }
        }
    }

    fun loadWeatherData(city: CityEntity) {
        viewModelScope.launch {
            _uiState.value = WeatherUiState.Loading
            try {
                val current = repository.getCurrentWeather(city.lat, city.lon)
                val forecast = repository.getForecast(city.lat, city.lon)
                val aqi = repository.getAirQuality(city.lat, city.lon)
                _uiState.value = WeatherUiState.Success(city, current, forecast, aqi)
            } catch (e: Exception) {
                _uiState.value = WeatherUiState.Error(e.message ?: "Unknown error occurred")
            }
        }
    }

    fun searchCities(query: String) {
        viewModelScope.launch {
            if (query.isBlank()) {
                _searchResults.value = emptyList()
                return@launch
            }
            try {
                _searchResults.value = repository.searchCity(query)
            } catch (e: Exception) {
                _searchResults.value = emptyList()
            }
        }
    }

    fun addCity(geo: GeocodingResponse) {
        viewModelScope.launch {
            val city = CityEntity(geo.name, geo.lat, geo.lon, geo.country)
            repository.saveCity(city)
            _searchResults.value = emptyList()
            loadWeatherData(city)
        }
    }
}

class WeatherViewModelFactory(private val repository: WeatherRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WeatherViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return WeatherViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
