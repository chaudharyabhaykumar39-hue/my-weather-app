package com.example.ui

import android.widget.FrameLayout
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.data.*
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun HomeScreen(
    viewModel: WeatherViewModel,
    onNavigateToSearch: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    // Hazy frosted background gradient based on conditions
    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF8A9EA7), // Hazy top
            Color(0xFF4A5F6A)  // Darker bottom
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundBrush)
    ) {
        when (val state = uiState) {
            is WeatherUiState.Loading -> {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center),
                    color = Color.White
                )
            }
            is WeatherUiState.Error -> {
                Text(
                    text = "Error: ${state.message}",
                    color = Color.White,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
            is WeatherUiState.Success -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                ) {
                    // Top Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 48.dp, start = 16.dp, end = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onNavigateToSearch) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu", tint = Color.White)
                        }
                        Text(
                            text = state.city.name,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        IconButton(onClick = onNavigateToSearch) {
                            Icon(Icons.Default.Add, contentDescription = "Manage Cities", tint = Color.White)
                        }
                    }

                    // Main Content Scrollable
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp)
                    ) {
                        Spacer(modifier = Modifier.height(32.dp))
                        
                        // Header info
                        WeatherHeader(state.current, state.airQuality)
                        
                        Spacer(modifier = Modifier.height(32.dp))
                        
                        // 24 Hour Forecast
                        Text("24-Hour Forecast", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(8.dp))
                        HourlyForecastWidget(state.forecast)

                        Spacer(modifier = Modifier.height(24.dp))
                        
                        // 5 Day Forecast
                        Text("5-Day Forecast", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(8.dp))
                        FiveDayForecastWidget(state.forecast)

                        Spacer(modifier = Modifier.height(24.dp))
                        
                        // Details Grid
                        Text("Weather Details", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(8.dp))
                        WeatherDetailsGrid(state.current)
                        
                        Spacer(modifier = Modifier.height(24.dp))
                    }

                    // Banner Ad at Bottom
                    BannerAdView()
                }
            }
        }
    }
}

@Composable
fun WeatherHeader(current: CurrentWeatherResponse, aqi: AirQualityResponse) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val temp = current.main.temp.roundToInt()
        val desc = current.weather.firstOrNull()?.description?.capitalize(Locale.getDefault()) ?: ""
        val high = current.main.tempMax.roundToInt()
        val low = current.main.tempMin.roundToInt()
        val aqiValue = aqi.list.firstOrNull()?.main?.aqi ?: 1

        Text(
            text = "$temp°",
            fontSize = 96.sp,
            fontWeight = FontWeight.Light,
            color = Color.White
        )
        Text(
            text = "$desc $high° / $low°",
            fontSize = 18.sp,
            color = Color.White.copy(alpha = 0.9f)
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        Surface(
            color = Color.White.copy(alpha = 0.2f),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(
                text = "AQI $aqiValue",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                color = Color.White,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun HourlyForecastWidget(forecast: ForecastResponse) {
    Surface(
        color = Color.Black.copy(alpha = 0.15f),
        shape = RoundedCornerShape(24.dp)
    ) {
        LazyRow(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(forecast.list.take(8)) { item ->
                val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
                val time = timeFormat.format(Date(item.dt * 1000))
                val iconUrl = "https://openweathermap.org/img/wn/${item.weather.firstOrNull()?.icon}@2x.png"
                
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = time, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
                    AsyncImage(
                        model = iconUrl,
                        contentDescription = null,
                        modifier = Modifier.size(40.dp),
                        contentScale = ContentScale.Fit
                    )
                    Text(
                        text = "${item.main.temp.roundToInt()}°",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "${item.wind.speed.roundToInt()}km/h",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
fun FiveDayForecastWidget(forecast: ForecastResponse) {
    // Naive grouping by day for demonstration
    val dailyMap = forecast.list.groupBy { 
        SimpleDateFormat("EEE", Locale.getDefault()).format(Date(it.dt * 1000)) 
    }
    
    val days = dailyMap.keys.take(5).toList()
    val highTemps = days.map { day -> 
        dailyMap[day]?.maxOfOrNull { it.main.tempMax }?.toFloat() ?: 0f 
    }
    val lowTemps = days.map { day -> 
        dailyMap[day]?.minOfOrNull { it.main.tempMin }?.toFloat() ?: 0f 
    }
    val icons = days.map { day -> 
        dailyMap[day]?.firstOrNull()?.weather?.firstOrNull()?.icon ?: "01d" 
    }

    Surface(
        color = Color.Black.copy(alpha = 0.15f),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            days.forEachIndexed { index, day ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if(index == 0) "Today" else day,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )
                    
                    AsyncImage(
                        model = "https://openweathermap.org/img/wn/${icons[index]}.png",
                        contentDescription = null,
                        modifier = Modifier.size(32.dp)
                    )
                    
                    Row(
                        modifier = Modifier.weight(2f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            text = "${lowTemps[index].roundToInt()}°",
                            color = Color.White.copy(alpha = 0.6f),
                            modifier = Modifier.width(36.dp)
                        )
                        
                        // Mini Line Chart Simulation Space
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(4.dp)
                                .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                        ) {
                            // A real mini chart would go here, representing the range
                        }
                        
                        Text(
                            text = "${highTemps[index].roundToInt()}°",
                            color = Color.White,
                            modifier = Modifier.width(36.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.End
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WeatherDetailsGrid(current: CurrentWeatherResponse) {
    val df = SimpleDateFormat("HH:mm", Locale.getDefault())
    val sunrise = df.format(Date(current.sys.sunrise * 1000))
    val sunset = df.format(Date(current.sys.sunset * 1000))

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DetailCard("Wind", "${current.wind.speed} km/h", Modifier.weight(1f))
            DetailCard("Humidity", "${current.main.humidity}%", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DetailCard("Real Feel", "${current.main.feelsLike.roundToInt()}°", Modifier.weight(1f))
            DetailCard("Pressure", "${current.main.pressure} mb", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DetailCard("Sunrise", sunrise, Modifier.weight(1f))
            DetailCard("Sunset", sunset, Modifier.weight(1f))
        }
    }
}

@Composable
fun DetailCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Color.Black.copy(alpha = 0.15f),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun BannerAdView() {
    AndroidView(
        modifier = Modifier.fillMaxWidth(),
        factory = { context ->
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = "ca-app-pub-3940256099942544/6300978111" // Test Banner ID
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}
