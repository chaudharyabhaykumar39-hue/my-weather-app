package com.example.data

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class CurrentWeatherResponse(
    val weather: List<WeatherDescription>,
    val main: MainWeatherData,
    val wind: WindData,
    val sys: SysData,
    val name: String
)

@JsonClass(generateAdapter = true)
data class WeatherDescription(
    val id: Int,
    val main: String,
    val description: String,
    val icon: String
)

@JsonClass(generateAdapter = true)
data class MainWeatherData(
    val temp: Double,
    @Json(name = "feels_like") val feelsLike: Double,
    @Json(name = "temp_min") val tempMin: Double,
    @Json(name = "temp_max") val tempMax: Double,
    val pressure: Int,
    val humidity: Int
)

@JsonClass(generateAdapter = true)
data class WindData(
    val speed: Double,
    val deg: Int
)

@JsonClass(generateAdapter = true)
data class SysData(
    val sunrise: Long,
    val sunset: Long
)

@JsonClass(generateAdapter = true)
data class ForecastResponse(
    val list: List<ForecastItem>
)

@JsonClass(generateAdapter = true)
data class ForecastItem(
    val dt: Long,
    val main: MainWeatherData,
    val weather: List<WeatherDescription>,
    val wind: WindData,
    @Json(name = "dt_txt") val dtTxt: String
)

@JsonClass(generateAdapter = true)
data class AirQualityResponse(
    val list: List<AirQualityItem>
)

@JsonClass(generateAdapter = true)
data class AirQualityItem(
    val main: AirQualityMain
)

@JsonClass(generateAdapter = true)
data class AirQualityMain(
    val aqi: Int
)

@JsonClass(generateAdapter = true)
data class GeocodingResponse(
    val name: String,
    val lat: Double,
    val lon: Double,
    val country: String,
    val state: String?
)
