package com.example.data

import kotlinx.coroutines.flow.Flow

class WeatherRepository(
    private val apiService: WeatherService,
    private val cityDao: CityDao,
    private val apiKey: String
) {
    val savedCities: Flow<List<CityEntity>> = cityDao.getAllCities()

    suspend fun saveCity(city: CityEntity) = cityDao.insertCity(city)
    
    suspend fun deleteCity(name: String) = cityDao.deleteCity(name)

    suspend fun searchCity(query: String): List<GeocodingResponse> {
        return apiService.getCityCoordinates(query, limit = 5, apiKey = apiKey)
    }

    suspend fun getCurrentWeather(lat: Double, lon: Double): CurrentWeatherResponse {
        return apiService.getCurrentWeather(lat, lon, apiKey)
    }

    suspend fun getForecast(lat: Double, lon: Double): ForecastResponse {
        return apiService.getForecast(lat, lon, apiKey)
    }

    suspend fun getAirQuality(lat: Double, lon: Double): AirQualityResponse {
        return apiService.getAirQuality(lat, lon, apiKey)
    }
}
