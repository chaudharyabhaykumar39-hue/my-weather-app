package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import com.example.data.CityDatabase
import com.example.data.WeatherRepository
import com.example.data.WeatherService
import com.example.ui.WeatherApp
import com.example.ui.WeatherViewModel
import com.example.ui.WeatherViewModelFactory
import com.example.ui.theme.MyApplicationTheme
import com.google.android.gms.ads.MobileAds
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Initialize AdMob
    MobileAds.initialize(this) {}

    // Setup Retrofit
    val retrofit = Retrofit.Builder()
        .baseUrl("https://api.openweathermap.org/")
        .addConverterFactory(MoshiConverterFactory.create())
        .build()
    val weatherService = retrofit.create(WeatherService::class.java)

    // Setup Room Database
    val db = Room.databaseBuilder(
        applicationContext,
        CityDatabase::class.java, "weather-cities"
    ).build()

    val apiKey = BuildConfig.WEATHER_API_KEY.takeIf { it != "YOUR_OPENWEATHERMAP_API_KEY" } ?: "97fb43a2c1b3d68d7798b4a42c168822"
    val repository = WeatherRepository(weatherService, db.cityDao(), apiKey)
    val viewModelFactory = WeatherViewModelFactory(repository)

    setContent {
      MyApplicationTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            val viewModel: WeatherViewModel = viewModel(factory = viewModelFactory)
            WeatherApp(viewModel = viewModel)
        }
      }
    }
  }
}
